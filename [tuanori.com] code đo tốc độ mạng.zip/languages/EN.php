<?
////////hotkey         //translate this
define("lang_hotkey",  "en");
define("begin_test",   "Begin Speed Test");

define("app_name",     "PHP Network speed tester");

define("download",     "Download");
define("upload",       "Upload");
define("ping",         "Ping");
define("repeat",       "Repeat test");

define("download_mp3", "Downloading MP3:");
define("download_cd",  "Downloading CD:");
define("download_dvd", "Downloading DVD:");

define("ip_address",   "IP address:");
define("country_code", "Country code:");
define("state",        "State/Province:");
define("city",         "City:");

define("my_speed",     "My Speed"); // alt text for image
define("cookie_text",  "This site uses cookies. By continuing to browse the site, you are agreeing to our use of cookies.");
define("cookie_agree", "I agree");
define("cookie_more",  "Learn more");
?>