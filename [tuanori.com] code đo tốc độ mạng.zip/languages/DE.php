<?
////////hotkey         //translate this
define("lang_hotkey",  "de");
define("begin_test",   "Start Speed Test");

define("app_name",     "PHP Netzwerk Speed-Tester");

define("download",     "Herunterladen");
define("upload",       "Hochladen");
define("ping",         "Klingeln");
define("repeat",       "Wiederholen Sie den Test");

define("download_mp3", "Herunterladen MP3:");
define("download_cd",  "Herunterladen CD:");
define("download_dvd", "Herunterladen DVD:");

define("ip_address",   "IP Adresse:");
define("country_code", "Landesvorwahl:");
define("state",        "Staat / Provinz:");
define("city",         "Stadt:");

define("my_speed",     "Meine Geschwindigkeit"); // alt text for image
define("cookie_text",  "Diese Website benutzt Cookies. Durch die Fortsetzung der Website zu durchsuchen, stimmen Sie der Verwendung von Cookies.");
define("cookie_agree", "Ich stimme zu");
define("cookie_more",  "Mehr erfahren");
?>