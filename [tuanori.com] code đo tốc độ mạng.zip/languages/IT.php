<?
////////hotkey         //translate this
define("lang_hotkey",  "it");
define("begin_test",   "Inizia Speed Test");

define("app_name",     "Tester velocità PHP rete");

define("download",     "Scaricare");
define("upload",       "Caricare");
define("ping",         "Ping");
define("repeat",       "Ripetere il test");

define("download_mp3", "Scaricare MP3:");
define("download_cd",  "Scaricare CD:");
define("download_dvd", "Scaricare DVD:");

define("ip_address",   "Indirizzo IP:");
define("country_code", "Prefisso internazionale:");
define("state",        "Stato / Provincia:");
define("city",         "Città:");

define("my_speed",     "Mio Velocità"); // alt text for image
define("cookie_text",  "Questo sito utilizza cookies. Continuando a navigare il sito, l'utente accetta di utilizzare i cookie.");
define("cookie_agree", "Accetto");
define("cookie_more",  "Per saperne di più");
?>