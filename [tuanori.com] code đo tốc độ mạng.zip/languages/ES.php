<?
////////hotkey         //translate this
define("lang_hotkey",  "es");
define("begin_test",   "Comenzar la prueba de velocidad");

define("app_name",     "medidor de velocidad de red PHP");

define("download",     "Descargar");
define("upload",       "Subir");
define("ping",         "Silbido");
define("repeat",       "Eepetición de la prueba");

define("download_mp3", "Descarga de MP3:");
define("download_cd",  "Descarga de CD:");
define("download_dvd", "Descarga de DVD:");

define("ip_address",   "Dirección IP:");
define("country_code", "Código de país:");
define("state",        "Estado / Provincia:");
define("city",         "Ciudad:");

define("my_speed",     "Mi velocidad"); // alt text for image
define("cookie_text",  "Este sitio utiliza cookies. Al continuar navegar por el sitio, usted acepta el uso de cookies.");
define("cookie_agree", "Estoy de acuerdo");
define("cookie_more",  "Aprende más");
?>