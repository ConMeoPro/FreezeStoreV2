<?
////////hotkey         //translate this
define("lang_hotkey",  "fr");
define("begin_test",   "Début Test de vitesse");

define("app_name",     "Testeur de vitesse PHP Réseau");

define("download",     "Télécharger");
define("upload",       "Télécharger");
define("ping",         "Ping");
define("repeat",       "Répéter le test");

define("download_mp3", "Téléchargement MP3:");
define("download_cd",  "Téléchargement CD:");
define("download_dvd", "Téléchargement DVD:");

define("ip_address",   "Adresse IP:");
define("country_code", "Code postal:");
define("state",        "État / Province:");
define("city",         "Ville:");

define("my_speed",     "Ma Vitesse"); // alt text for image
define("cookie_text",  "Ce site utilise des cookies. En continuant à naviguer sur le site, vous acceptez notre utilisation des cookies.");
define("cookie_agree", "Je suis d'accord");
define("cookie_more",  "Apprendre encore plus");
?>