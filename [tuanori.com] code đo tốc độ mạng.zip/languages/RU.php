<?
////////hotkey         //translate this
define("lang_hotkey",  "ru");
define("begin_test",   "Начать тест скорости");

define("app_name",     "Скорость тестер PHP Сеть");

define("download",     "Скачать");
define("upload",       "Загрузить");
define("ping",         "пинг");
define("repeat",       "Повторить тест");

define("download_mp3", "Загрузка MP3:");
define("download_cd",  "Загрузка компакт-дисков:");
define("download_dvd", "Загрузка DVD:");

define("ip_address",   "айпи адрес:");
define("country_code", "Код страны:");
define("state",        "Штат / провинция:");
define("city",         "город:");

define("my_speed",     "Моя скорость"); // alt text for image
define("cookie_text",  "Этот сайт использует куки-файлы. Продолжая просматривать сайт, вы соглашаетесь с нашим использованием куки.");
define("cookie_agree", "согласен");
define("cookie_more",  "Выучить больше");
?>